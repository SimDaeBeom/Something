package compiler_proj;

import java.io.*;
import java.util.*;

/*
 * read rule.txt and add "-" in  index(1) of each rule;
 * */
//이름을 rule_list로 변경하자.
public class rules {
	
	private List<String> rules = new ArrayList<>();
	
	
	public rules() throws IOException  {
	
		rules.clear();
		BufferedReader br = new BufferedReader(new FileReader("rule.txt"));
		
	    while(true) {
	        String line = br.readLine();
	        if(line==null) break;
	        if(line.charAt(0)!='R'){
	        	StringBuilder newline = new StringBuilder(line);
	        	newline.insert(1, '-');
	        	newline.insert(0, '[');
	        	newline.append(']');
	        	rules.add(newline.toString());
	        } 
	    }
	    br.close();
	    rules.add(0, "[S->E]");
	
	}
	public List<String> getRules(){
		return this.rules;
	}
	
	
}
