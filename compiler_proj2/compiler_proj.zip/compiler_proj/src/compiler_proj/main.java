package compiler_proj;

import java.io.IOException;

public class main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		rules Rules = new rules();
	
		System.out.println(Rules.getRules());
	
	}

}
