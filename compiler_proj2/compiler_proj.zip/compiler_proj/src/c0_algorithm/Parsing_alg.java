package c0_algorithm;

import compiler_proj.*;
import java.util.*;

public class Parsing_alg {
	private List<String> rules = new ArrayList<>();
	public Parsing_alg() {
			
		
		
	}

}
